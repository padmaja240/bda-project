import pandas as pd

df = pd.read_csv('../Datasets/customer_summary.csv')

high_value = df[df['Segment'] == 'High Value']
medium_value = df[df['Segment'] == 'Medium Value']
low_value = df[df['Segment'] == 'Low Value']

print('High Value Customers:', len(high_value))
print('Medium Value Customers:', len(medium_value))
print('Low Value Customers:', len(low_value))
