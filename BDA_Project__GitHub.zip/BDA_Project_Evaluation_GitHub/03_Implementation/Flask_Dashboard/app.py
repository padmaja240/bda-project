from flask import Flask, render_template
import pandas as pd
import plotly.express as px
import plotly.utils
import json
from collections import Counter
from itertools import combinations

app = Flask(__name__)
DATA_PATH = 'data/customer_transactions.csv'

def load_data():
    df = pd.read_csv(DATA_PATH)
    df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'])
    return df

def to_json(fig):
    fig.update_layout(template='plotly_white', paper_bgcolor='white', plot_bgcolor='white')
    return json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

def metrics(df):
    total_sales = round(df['Amount'].sum(), 2)
    total_orders = int(df['InvoiceID'].nunique())
    total_customers = int(df['CustomerID'].nunique())
    avg_order_value = round(df.groupby('InvoiceID')['Amount'].sum().mean(), 2)
    total_quantity = int(df['Quantity'].sum())
    return total_sales, total_orders, total_customers, avg_order_value, total_quantity

def sales_trend(df):
    x = df.groupby(df['InvoiceDate'].dt.to_period('M'))['Amount'].sum().reset_index()
    x['InvoiceDate'] = x['InvoiceDate'].astype(str)
    return to_json(px.line(x, x='InvoiceDate', y='Amount', markers=True, title='Monthly Sales Trend'))

def category_revenue(df):
    x = df.groupby('Category')['Amount'].sum().reset_index().sort_values(by='Amount', ascending=False)
    return to_json(px.bar(x, x='Category', y='Amount', title='Category-wise Revenue', text_auto='.2s'))

def top_products(df):
    x = df.groupby('ProductName')['Quantity'].sum().reset_index().sort_values(by='Quantity', ascending=False).head(10)
    return to_json(px.bar(x, x='ProductName', y='Quantity', title='Top Products by Quantity Sold', text_auto=True))

def region_sales(df):
    x = df.groupby('Region')['Amount'].sum().reset_index().sort_values(by='Amount', ascending=False)
    return to_json(px.pie(x, names='Region', values='Amount', title='Region-wise Sales Share'))

def payment_mode(df):
    x = df.groupby('PaymentMode')['InvoiceID'].nunique().reset_index(name='Orders')
    return to_json(px.bar(x, x='PaymentMode', y='Orders', title='Payment Mode Usage', text_auto=True))

def segment_customers(df):
    s = df.groupby(['CustomerID', 'CustomerName']).agg(Frequency=('InvoiceID', 'nunique'), Monetary=('Amount', 'sum')).reset_index()
    def label(v):
        if v >= 100000:
            return 'High Value'
        elif v >= 40000:
            return 'Medium Value'
        return 'Low Value'
    s['Segment'] = s['Monetary'].apply(label)
    return s.sort_values(by='Monetary', ascending=False)

def segment_chart(seg):
    x = seg.groupby('Segment')['CustomerID'].count().reset_index(name='Customers')
    return to_json(px.bar(x, x='Segment', y='Customers', title='Customer Segmentation', text_auto=True))

def recommendations(df):
    baskets = df.groupby('InvoiceID')['ProductName'].apply(list)
    counts = Counter()
    for items in baskets:
        unique_items = sorted(set(items))
        for pair in combinations(unique_items, 2):
            counts[pair] += 1
    return [{'base': a, 'recommended': b, 'count': c} for (a,b), c in counts.most_common(8)]

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/dashboard')
def dashboard():
    df = load_data()
    total_sales, total_orders, total_customers, avg_order_value, total_quantity = metrics(df)
    seg = segment_customers(df)
    return render_template(
        'dashboard.html',
        total_sales=total_sales,
        total_orders=total_orders,
        total_customers=total_customers,
        avg_order_value=avg_order_value,
        total_quantity=total_quantity,
        sales_trend=sales_trend(df),
        category_revenue=category_revenue(df),
        top_products=top_products(df),
        region_sales=region_sales(df),
        payment_mode=payment_mode(df),
        segment_chart=segment_chart(seg),
        top_customers=seg[['CustomerName','Frequency','Monetary','Segment']].head(8).to_dict(orient='records'),
        recommendations=recommendations(df)
    )

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)
