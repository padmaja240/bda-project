# Climate Change Big Data Analytics

## Setup
pip install -r requirements.txt

## Run (Local)
python spark_job.py

## Notebook
Open notebook.ipynb in Jupyter
