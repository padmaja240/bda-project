import pandas as pd
import plotly.express as px

df = pd.read_csv("data/sample_weather.csv")

fig = px.line(df, x='date', y='temp', title='Temperature Trend')
fig.show()
