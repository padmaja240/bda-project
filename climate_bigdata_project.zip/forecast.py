import pandas as pd
from sklearn.linear_model import LinearRegression
import numpy as np

df = pd.read_csv("data/sample_weather.csv")

df['year'] = pd.to_datetime(df['date']).dt.year

X = df[['year']]
y = df['temp']

model = LinearRegression()
model.fit(X, y)

future_years = np.array(range(2005, 2015)).reshape(-1,1)
preds = model.predict(future_years)

print("Future Predictions:", preds)
