import pandas as pd
import numpy as np

df = pd.read_csv("data/sample_weather.csv")

mean = df['temp'].mean()
std = df['temp'].std()

df['z_score'] = (df['temp'] - mean) / std

df['anomaly'] = df['z_score'].abs() > 2

print(df)
