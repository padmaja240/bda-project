from pyspark.sql import SparkSession
from pyspark.sql.functions import avg

spark = SparkSession.builder.appName("ClimateAnalysis").getOrCreate()

df = spark.read.csv("data/sample_weather.csv", header=True, inferSchema=True)

df.groupBy("region").agg(avg("temp").alias("avg_temp")).show()

spark.stop()
